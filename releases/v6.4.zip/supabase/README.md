## Deploy function 
`npx supabase functions deploy --project-ref ewfuuzgeekykbdmmysck`